package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_resultado_km.*
import java.util.*

class ResultadoKmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado_km)

        val sh = getSharedPreferences("KM", Context.MODE_PRIVATE)
        var key = "KeyLastKm"
        var last = sh.getString(key,"")
        var tkn = StringTokenizer(last.toString(),";")

        var ini = tkn.nextToken()
        var fim = tkn.nextToken()
        var litro = tkn.nextToken()

        var kmlitro =  ( fim!!.toDouble() - ini!!.toDouble()) / litro!!.toDouble()

        txtKmLitro.setText(String.format("%.2f",kmlitro)+"Km/Litros")

        btVoltarResult.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularKmActivity::class.java)
            startActivity(intent)
        }
    }
}