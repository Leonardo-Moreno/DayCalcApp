package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_resultado_km.*
import kotlinx.android.synthetic.main.activity_resultado_taxa.*
import java.util.*

class ResultadoTaxaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado_taxa)

        val sh = getSharedPreferences("TAXA", Context.MODE_PRIVATE)
        var key = "KeyLastTaxa"
        var last = sh.getString(key,"")
        var tkn = StringTokenizer(last.toString(),";")

        var valor = tkn.nextToken()
        var taxa = tkn.nextToken()

        var recebe =  (valor.toDouble() -(valor.toDouble() * (taxa.toDouble()/100)))
        var repasse =((100 * valor.toDouble()) / (100 - taxa.toDouble()))

        txtReceb.setText("R$"+String.format("%.2f",recebe))
        txtRepasse.setText("R$"+String.format("%.2f",repasse))

        btVoltarResultadoTaxa.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularTaxaActivity::class.java)
            startActivity(intent)
        }
    }
}