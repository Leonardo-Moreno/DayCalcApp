package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calcular_combu.*
import kotlinx.android.synthetic.main.activity_calcular_km.*
import java.lang.StringBuilder

class CalcularCombuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular_combu)

        val sh = getSharedPreferences("COMBU", Context.MODE_PRIVATE)

        btCalcularResultadoCombu.setOnClickListener { v: View? ->

            if(!(txtGasolina.text.isNullOrEmpty())  && !(txtAlcool.text.isNullOrEmpty()) ){
                var hist = "KeyHistCombu"
                var key = "KeyLastCombu"

                val str = StringBuilder()
                str.append(txtGasolina.text.toString()).append(";")
                str.append(txtAlcool.text.toString()).append(";")
                sh.edit().putString(key.toString(),str.toString()).apply()

                var histLista = sh.getString(hist,"")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(txtGasolina.text.toString()).append(";")
                str2.append(txtAlcool.text.toString()).append(";")

                sh.edit().putString(hist.toString(),str2.toString()).apply()

                val intent = Intent(this,ResultadoCombuActivity::class.java)
                startActivity(intent)
            }
            else{
                Toast.makeText(this,"Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }

        }
        btHistCombu.setOnClickListener { v: View? ->
            val intent = Intent(this,HistCombuActivity::class.java)
            startActivity(intent)
        }

        btVoltaMenuCombu.setOnClickListener { v: View? ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
}