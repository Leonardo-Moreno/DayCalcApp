package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_hist_km.*
import java.util.*

class HistKmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hist_km)

        val sh = getSharedPreferences("KM", Context.MODE_PRIVATE)
        var hist = "KeyHistKm"
        var histList = sh.getString(hist,"")
        var tkn = StringTokenizer(histList.toString(),";")

        while(tkn.hasMoreTokens()){
            var ini = tkn.nextToken()
            var fim = tkn.nextToken()
            var litro = tkn.nextToken()
            var kmlitro =  ( fim!!.toDouble() - ini!!.toDouble()) / litro!!.toDouble()
            var conta = ("("+fim+"kmFinal  -"+ini+"kmInicial)/"+litro+"l  ="+String.format("%.2f",kmlitro)+"km/litro")


            txtListaKm.append(conta.toString()+"\n")
        }


        btVoltarHistoryKm.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularKmActivity::class.java)
            startActivity(intent)
        }
    }
}