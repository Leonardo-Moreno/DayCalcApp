package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calcular_km.*
import kotlinx.android.synthetic.main.activity_calcular_taxa.*
import kotlinx.android.synthetic.main.activity_calcular_taxa.btVoltaMenu
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.StringBuilder

class CalcularTaxaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular_taxa)

        val sh = getSharedPreferences("TAXA", Context.MODE_PRIVATE)

        btResultadoTaxa.setOnClickListener { v: View? ->
            if(!(txtValor.text.isNullOrEmpty()) && !(txtTaxa.text.isNullOrEmpty()) ){
                var hist = "KeyHistTaxa"
                var key = "KeyLastTaxa"

                val str = StringBuilder()
                str.append(txtValor.text.toString()).append(";")
                str.append(txtTaxa.text.toString()).append(";")
                sh.edit().putString(key.toString(),str.toString()).apply()

                var histLista = sh.getString(hist,"")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(txtValor.text.toString()).append(";")
                str2.append(txtTaxa.text.toString()).append(";")

                sh.edit().putString(hist.toString(),str2.toString()).apply()
                val intent = Intent(this,ResultadoTaxaActivity::class.java)
                startActivity(intent)
            }else{
                Toast.makeText(this,"Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }

        }

        btHistTaxa.setOnClickListener { v: View? ->
            val intent = Intent(this,HistTaxaActivity::class.java)
            startActivity(intent)
        }

        btVoltaMenu.setOnClickListener { v: View? ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
}