package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_calcular_combu.*
import kotlinx.android.synthetic.main.activity_resultado_combu.*
import kotlinx.android.synthetic.main.activity_resultado_taxa.*
import java.util.*

class ResultadoCombuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado_combu)

        val sh = getSharedPreferences("COMBU", Context.MODE_PRIVATE)
        var key = "KeyLastCombu"
        var last = sh.getString(key,"")
        var tkn = StringTokenizer(last.toString(),";")

        var gas = tkn.nextToken()
        var alcool = tkn.nextToken()

        var resultado =  alcool.toDouble()/gas.toDouble()

        if (resultado >= 0.7){
            txtCombustivel.setText("Compensa o uso da gasolina")
        }
        else{
            txtCombustivel.setText("Compensa o uso do álcool")

        }

        btVoltarResultCombu.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularCombuActivity::class.java)
            startActivity(intent)
        }
    }
}