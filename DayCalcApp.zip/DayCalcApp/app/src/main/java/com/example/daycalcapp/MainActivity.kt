package com.example.daycalcapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btCalKm.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularKmActivity::class.java)
            startActivity(intent)
        }
        btCalTaxa.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularTaxaActivity::class.java)
            startActivity(intent)
        }
    }
}