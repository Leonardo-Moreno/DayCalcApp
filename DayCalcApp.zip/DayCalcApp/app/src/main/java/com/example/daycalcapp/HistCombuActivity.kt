package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_hist_combu.*
import kotlinx.android.synthetic.main.activity_hist_km.*
import kotlinx.android.synthetic.main.activity_resultado_combu.*
import java.util.*

class HistCombuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hist_combu)

        val sh = getSharedPreferences("COMBU", Context.MODE_PRIVATE)
        var hist = "KeyHistCombu"
        var histList = sh.getString(hist,"")
        var tkn = StringTokenizer(histList.toString(),";")

        txtListaCombu.append("álcool vs gasolina = Compensa o uso de ?"+"\n")
        while(tkn.hasMoreTokens()){
            var gas = tkn.nextToken()
            var alcool = tkn.nextToken()

            var resultado =  alcool.toDouble()/gas.toDouble()
            var conta = alcool + " x "+ gas

            if (resultado >= 0.7){
                txtListaCombu.append(conta+" = Gasolina"+"\n")
            }
            else {
                txtListaCombu.append(conta + " = Álcool" + "\n")

            }
        }


        btVoltarHistoryCombu.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularCombuActivity::class.java)
            startActivity(intent)
        }
    }
}