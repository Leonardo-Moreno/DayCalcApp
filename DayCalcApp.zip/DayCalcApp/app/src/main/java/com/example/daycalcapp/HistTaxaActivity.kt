package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_hist_km.*
import kotlinx.android.synthetic.main.activity_hist_taxa.*
import kotlinx.android.synthetic.main.activity_resultado_taxa.*
import java.util.*

class HistTaxaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hist_taxa)

        val sh = getSharedPreferences("TAXA", Context.MODE_PRIVATE)
        var hist = "KeyHistTaxa"
        var histList = sh.getString(hist,"")
        var tkn = StringTokenizer(histList.toString(),";")

        while(tkn.hasMoreTokens()){
            var valor = tkn.nextToken()
            var taxa = tkn.nextToken()

            var recebe =  (valor.toDouble() -(valor.toDouble() * (taxa.toDouble()/100)))
            var repasse =((100 * valor.toDouble()) / (100 - taxa.toDouble()))

            var contarecebe = "R$"+valor+" - R$"+String.format("%.2f",(valor.toDouble() * (taxa.toDouble()/100)))+" =  R$"+String.format("%.2f",recebe)
            var contarepasse = "(100 x R$"+valor+") / (100 - "+taxa+"%) = R$"+String.format("%.2f",repasse)

            txtHistTaxa.append(contarecebe.toString()+"\n")
            txtHistTaxa.append(contarepasse.toString()+"\n")
        }

        btVoltaHistCalcularTaxa.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularTaxaActivity::class.java)
            startActivity(intent)
        }
    }
}