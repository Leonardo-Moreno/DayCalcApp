package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_resultado_imc.*
import java.util.*

class ResultadoImcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado_imc)

        //pra salvar na mémoria
        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)
        var key = "KeyLastImc"
        var last = sh.getString(key,"")
        var tkn = StringTokenizer(last.toString(),";")

        var peso = tkn.nextToken()
        var alt = tkn.nextToken()

        var imc = peso!!.toDouble() /(alt!!.toDouble() * alt!!.toDouble())
        txtContaImc.setText("IMC = "+String.format("%.2f",imc)+"kg/m2")
        if (imc < 18.5){
            txtCalssificacao.setText("Magreza")
            txtObesidade.setText("0")
        }
        else if ((imc > 18.5) && (imc < 24.9)){
            txtCalssificacao.setText("Normal")
            txtObesidade.setText("0")
        }
        else if ((imc > 25.0) && (imc < 29.9)){
            txtCalssificacao.setText("Sobrepeso")
            txtObesidade.setText("1")
        }
        else if ((imc > 30.0) && (imc < 39.9)){
            txtCalssificacao.setText("Obesidade")
            txtObesidade.setText("2")
        }
        else{
            txtCalssificacao.setText("Obesidade Grave")
            txtObesidade.setText("3")
        }
        btVoltarResult.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularImcActivity::class.java)
            startActivity(intent)
        }
    }
}