package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_hist_imc.*
import java.util.*

class HistImcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hist_imc)
        //pra salvar na mémoria
        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)
        var hist = "KeyHistImc"
        var histList = sh.getString(hist,"")
        var tkn = StringTokenizer(histList.toString(),";")

        while(tkn.hasMoreTokens()){
            var peso = tkn.nextToken()
            var alt = tkn.nextToken()
            var imc = peso!!.toDouble() /(alt!!.toDouble() * alt!!.toDouble())
            var conta = ("IMC = "+peso.toString()+"kg/("+alt.toString()+"m*"+alt.toString()+"m) = "+String.format("%.2f",imc)+"kg/m2")

            txtListaImc.append(conta.toString()+"\n")

            if (imc < 18.5){
                txtListaImc.append("Classificação:Magreza"+"\n")
                txtListaImc.append("Grau:0"+"\n")
            }
            else if ((imc > 18.5) && (imc < 24.9)){
                txtListaImc.append("Classificação:Normal"+"\n")
                txtListaImc.append("Grau:0"+"\n")
            }
            else if ((imc > 25.0) && (imc < 29.9)){
                txtListaImc.append("Classificação:Sobrepeso"+"\n")
                txtListaImc.append("Grau:1"+"\n")
            }
            else if ((imc > 30.0) && (imc < 39.9)){
                txtListaImc.append("Classificação:Obesidade"+"\n")
                txtListaImc.append("Grau:2"+"\n")
            }
            else{
                txtListaImc.append("Classificação:Obesidade Grave"+"\n")
                txtListaImc.append("Grau:3"+"\n")
            }
            txtListaImc.append("*******************************************"+"\n")
        }


        btVoltarHistCalcularImc.setOnClickListener { v: View? ->
            val intent = Intent(this,CalcularImcActivity::class.java)
            startActivity(intent)
        }
    }
}