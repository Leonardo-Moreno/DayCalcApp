package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calcular_imc.*
import java.lang.StringBuilder

class CalcularImcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular_imc)


        //pra salvar na mémoria
        val sh = getSharedPreferences("IMC", Context.MODE_PRIVATE)

        btCalcular.setOnClickListener { v: View?->
            if (!(txtAltura.text.isNullOrEmpty()) && !(txtPeso.text.isNullOrEmpty())){
                var hist = "KeyHistImc"
                var key = "KeyLastImc"

                val str = StringBuilder()
                str.append(txtPeso.text.toString()).append(";")
                str.append(txtAltura.text.toString()).append(";")
                sh.edit().putString(key.toString(),str.toString()).apply()

                var histLista = sh.getString(hist,"")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(txtPeso.text.toString()).append(";")
                str2.append(txtAltura.text.toString()).append(";")

                sh.edit().putString(hist.toString(),str2.toString()).apply()
                val intent = Intent(this,ResultadoImcActivity::class.java)
                startActivity(intent)

            }
            else{
                Toast.makeText(this,"Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }
        }
        btHist.setOnClickListener { v: View? ->
            val intent = Intent(this,HistImcActivity::class.java)
            startActivity(intent)
        }
        btVoltarImMain.setOnClickListener { v: View? ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }


    }
}