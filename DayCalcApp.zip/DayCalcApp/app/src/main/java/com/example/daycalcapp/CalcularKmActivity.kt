package com.example.daycalcapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calcular_km.*
import java.lang.StringBuilder

class CalcularKmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular_km)

        val sh = getSharedPreferences("KM", Context.MODE_PRIVATE)

        btCalcularKm.setOnClickListener { v: View? ->
            if(!(txtKmIncial.text.isNullOrEmpty()) && !(txtKmFinal.text.isNullOrEmpty()) && !(txtLitros.text.isNullOrEmpty()) ){
                var hist = "KeyHistKm"
                var key = "KeyLastKm"

                val str = StringBuilder()
                str.append(txtKmIncial.text.toString()).append(";")
                str.append(txtKmFinal.text.toString()).append(";")
                str.append(txtLitros.text.toString()).append(";")
                sh.edit().putString(key.toString(),str.toString()).apply()

                var histLista = sh.getString(hist,"")

                val str2 = StringBuilder()
                str2.append(histLista.toString()).append(";")
                str2.append(txtKmIncial.text.toString()).append(";")
                str2.append(txtKmFinal.text.toString()).append(";")
                str2.append(txtLitros.text.toString()).append(";")

                sh.edit().putString(hist.toString(),str2.toString()).apply()

                val intent = Intent(this,ResultadoKmActivity::class.java)
                startActivity(intent)
            }
            else{
                Toast.makeText(this,"Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }
        }
        btVoltaMenu.setOnClickListener { v: View? ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        btHistKm.setOnClickListener { v: View? ->
            val intent = Intent(this,HistKmActivity::class.java)
            startActivity(intent)
        }

    }
}